const https = require("https");
const fs = require("fs");
const path = require("path");
const { spawn, execFileSync } = require("child_process");
const { pipeline } = require("stream/promises");

const CLIENT = process.env.CLIENT || "ios"; // client type: chrome (default), android, or ios if you want to be able to read viewonce

const RELEASE_URL =
	"https://github.com/Thruqe/whatsrook/releases/download/alpha/whatsrook-linux-amd64.tar.gz";
const DEST_DIR = path.join(__dirname, "whatsrook-bin");
const TAR_PATH = path.join(__dirname, "whatsrook.tar.gz");
const BINARY_PATH = path.join(DEST_DIR, "whatsrook");

const YTDLP_URL =
	"https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp";
const YTDLP_DIR = path.join(__dirname, "bin");
const YTDLP_PATH = path.join(YTDLP_DIR, "yt-dlp");

const PHONE_FILE = path.join(__dirname, "phone.txt");
const LOG_DIR = path.join(__dirname, "logs");

const sessions = new Map(); // phone -> { proc, pairCode, appInfo, clientInfo }

function ensureTarDependency() {
	try {
		require.resolve("tar");
	} catch {
		execFileSync("npm", ["install", "tar"], {
			cwd: __dirname,
			stdio: "inherit",
		});
	}
	return require("tar");
}

function ensureYtDlp() {
	fs.mkdirSync(YTDLP_DIR, { recursive: true });
	if (fs.existsSync(YTDLP_PATH)) return;
	execFileSync("curl", ["-L", YTDLP_URL, "-o", YTDLP_PATH], {
		stdio: "inherit",
	});
	try {
		fs.chmodSync(YTDLP_PATH, 0o755);
	} catch (err) {
		// Ignore chmod errors in unprivileged panel/container environments
	}
}

function download(url, dest) {
	console.log(`[GitHub Fetch] Requesting: ${url}`);
	return new Promise((resolve, reject) => {
		const parsedUrl = new URL(url);
		const options = {
			hostname: parsedUrl.hostname,
			path: parsedUrl.pathname + parsedUrl.search,
			headers: {
				"User-Agent":
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
				Accept: "*/*",
			},
		};
		https
			.get(options, (res) => {
				if (
					res.statusCode >= 300 &&
					res.statusCode < 400 &&
					res.headers.location
				) {
					console.log(`[GitHub Fetch] Redirecting (${res.statusCode}) -> ${res.headers.location}`);
					return download(res.headers.location, dest).then(resolve, reject);
				}
				if (res.statusCode !== 200) {
					return reject(new Error(`Download failed with status ${res.statusCode} for ${url}`));
				}
				console.log(`[GitHub Fetch] Downloading payload to ${dest}...`);
				const fileStream = fs.createWriteStream(dest);
				pipeline(res, fileStream).then(resolve, reject);
			})
			.on("error", reject);
	});
}

async function extract(tar, tarPath, destDir) {
	fs.mkdirSync(destDir, { recursive: true });
	await tar.x({ file: tarPath, cwd: destDir });
}

function readPhoneList() {
	if (!fs.existsSync(PHONE_FILE)) return [];
	return fs
		.readFileSync(PHONE_FILE, "utf8")
		.split("\n")
		.map((line) => line.trim())
		.filter(Boolean);
}

function printRow(phone, label, value) {
	console.log(`SESSION ${phone.padEnd(15)} | ${label.padEnd(11)} | ${value}`);
}

function parseLine(phone, line) {
	const state = sessions.get(phone);
	if (!state) return;

	const cleanLine = line.replace(/\x1B\[[0-9;]*m/g, "").trim();
	if (!cleanLine) return;

	console.log(`[Session ${phone}] ${cleanLine}`);

	// 1. Direct Pair Code matching
	const directPairCodeMatch =
		cleanLine.match(/PAIR CODE:?\s*(?:%s)?\s*=?\s*([A-Z0-9]{4}-?[A-Z0-9]{4}|[A-Z0-9-]{8,})/i) ||
		cleanLine.match(/pair code issued.*code=([A-Z0-9-]+)/i) ||
		cleanLine.match(/Enter this code on your phone:\s*([A-Z0-9-]+)/i);

	if (directPairCodeMatch && directPairCodeMatch[1] && directPairCodeMatch[1] !== "%s") {
		state.pairCode = directPairCodeMatch[1].trim();
		state.awaitingPairCode = false;
		printRow(phone, "PAIR CODE", state.pairCode);
		return;
	}

	if (/PAIR CODE:/i.test(cleanLine)) {
		state.awaitingPairCode = true;
		return;
	}

	if (state.awaitingPairCode) {
		const followUpMatch = cleanLine.match(/^=?\s*([A-Z0-9]{4}-?[A-Z0-9]{4}|[A-Z0-9-]{8,})$/i);
		if (followUpMatch && followUpMatch[1] !== "%s") {
			state.pairCode = followUpMatch[1].trim();
			state.awaitingPairCode = false;
			printRow(phone, "PAIR CODE", state.pairCode);
			return;
		}
	}

	// 2. Generic App and Client Info matching
	const appInfoMatch = cleanLine.match(/\[App INFO\]\s+(.+)/i);
	const clientInfoMatch = cleanLine.match(/\[Client INFO\]\s+(.+)/i);

	if (appInfoMatch && !/PAIR CODE/i.test(cleanLine)) {
		state.appInfo = appInfoMatch[1].trim();
		printRow(phone, "APP INFO", state.appInfo);
	}
	if (clientInfoMatch) {
		state.clientInfo = clientInfoMatch[1].trim();
		printRow(phone, "CLIENT INFO", state.clientInfo);
	}
}

function getExec(extraArgs) {
	if (fs.existsSync(BINARY_PATH)) {
		try {
			fs.chmodSync(BINARY_PATH, 0o755);
		} catch {}
		return { cmd: BINARY_PATH, args: extraArgs, cwd: DEST_DIR };
	}
	throw new Error(`Executable binary not found at ${BINARY_PATH}`);
}

function startSession(phone) {
	if (sessions.has(phone)) return;

	fs.mkdirSync(LOG_DIR, { recursive: true });
	const logPath = path.join(LOG_DIR, `${phone}.log`);
	const logStream = fs.createWriteStream(logPath, { flags: "a" });

	const sessionArgs = ["-s", phone, "-c", CLIENT, "-p"];
	const execInfo = getExec(sessionArgs);

	console.log(`[Session ${phone}] Starting whatsrook via: ${execInfo.cmd} ${execInfo.args.join(" ")} (cwd: ${execInfo.cwd})`);

	const proc = spawn(execInfo.cmd, execInfo.args, {
		cwd: execInfo.cwd,
		env: {
			...process.env,
			PATH: `${YTDLP_DIR}:${process.env.PATH}`,
		},
	});

	const state = { proc, pairCode: null, appInfo: null, clientInfo: null, awaitingPairCode: false };
	sessions.set(phone, state);

	let stdoutBuf = "";
	proc.stdout.on("data", (chunk) => {
		logStream.write(chunk);
		stdoutBuf += chunk.toString();
		let idx;
		while ((idx = stdoutBuf.indexOf("\n")) >= 0) {
			const line = stdoutBuf.slice(0, idx);
			stdoutBuf = stdoutBuf.slice(idx + 1);
			parseLine(phone, line);
		}
	});

	let stderrBuf = "";
	proc.stderr.on("data", (chunk) => {
		logStream.write(chunk);
		stderrBuf += chunk.toString();
		let idx;
		while ((idx = stderrBuf.indexOf("\n")) >= 0) {
			const line = stderrBuf.slice(0, idx);
			stderrBuf = stderrBuf.slice(idx + 1);
			parseLine(phone, line);
		}
	});

	proc.on("exit", (code, signal) => {
		console.log(`[Session ${phone}] Process exited with code ${code} (signal: ${signal})`);
		logStream.end();
	});
}

function stopSession(phone) {
	const state = sessions.get(phone);
	if (!state) return;

	console.log(`[Session ${phone}] Logging out & stopping session...`);

	const logoutArgs = ["-s", phone, "-c", CLIENT, "-l"];
	const execInfo = getExec(logoutArgs);

	try {
		execFileSync(execInfo.cmd, execInfo.args, {
			cwd: execInfo.cwd,
			stdio: "ignore",
		});
	} catch {}

	if (!state.proc.killed) {
		state.proc.kill();
	}
	sessions.delete(phone);
}

function reconcile() {
	const current = new Set(readPhoneList());
	console.log(`[Reconcile] Active phone list (${current.size} session/s): [${Array.from(current).join(", ")}]`);

	for (const phone of current) {
		if (!sessions.has(phone)) {
			startSession(phone);
		}
	}

	for (const phone of sessions.keys()) {
		if (!current.has(phone)) {
			stopSession(phone);
		}
	}
}

async function main() {
	const tar = ensureTarDependency();
	ensureYtDlp();

	if (process.env.FORCE_DOWNLOAD === "1" || process.env.REDOWNLOAD === "1") {
		console.log("FORCE_DOWNLOAD requested. Removing existing binary folder...");
		if (fs.existsSync(DEST_DIR)) {
			fs.rmSync(DEST_DIR, { recursive: true, force: true });
		}
	}

	if (!fs.existsSync(BINARY_PATH)) {
		console.log(`[GitHub Fetch] Binary not found at ${BINARY_PATH}. Downloading release asset from: ${RELEASE_URL}`);
		try {
			await download(RELEASE_URL, TAR_PATH);
			console.log(`[GitHub Fetch] Extracting release asset to ${DEST_DIR}...`);
			await extract(tar, TAR_PATH, DEST_DIR);
			if (fs.existsSync(TAR_PATH)) {
				fs.unlinkSync(TAR_PATH);
			}
			console.log("[GitHub Fetch] Release binary downloaded and extracted successfully.");
		} catch (err) {
			console.warn("[GitHub Fetch] Release download/extract failed:", err.message);
		}
	}

	if (fs.existsSync(BINARY_PATH)) {
		console.log(`Using binary at: ${BINARY_PATH}`);
	}

	reconcile();

	if (fs.existsSync(PHONE_FILE)) {
		fs.watch(PHONE_FILE, { persistent: true }, () => {
			reconcile();
		});
	}
}

main().catch((err) => {
	console.error("Failed:", err);
	process.exit(1);
});